// ==UserScript==
// @name        xhamster
// @description This is your new file, start writing code
// @match       *://xhamster.com/*
// @match       *://xhamster2.com/*
// @run-at      document-idle
// @noframes

// ==/UserScript==
(function () {
  const url = location.pathname;
  const page = location.pathname
    .split("/")
    .filter((a) => a.length >= 1)
    .filter((a) => !["gay", "shemale", "hd"].includes(a))[0];
  const search = location.search;
  const params = search.replace("?", "").split("&");
  params.push("filter=spin");
  console.log({ url, page, search, params });

  document.querySelectorAll("[class*='yld']").forEach((a) => a.remove());
  document.querySelectorAll("[data-role*='yld']").forEach((a) => a.remove());

  switch (page) {
    case "videos":
      let a;

      let vid = document.createElement("video");
      vid.classList.add("my-vid");
      vid.setAttribute("controls", true);
      vid.setAttribute("disablePictureInPicture", false);
      vid.setAttribute("playsinline", true);
      vid.setAttribute("preload", "auto");
      vid.setAttribute("autoplay", false);
      vid.setAttribute("type", "video/mp4");

      if (mobileCheck()) {
        let container = document.querySelector(".video_container");
        let raw = container.querySelector("noscript").innerText;
        let url = raw.substring(raw.indexOf("https://"), raw.indexOf('" poster'));
        let fallback = container.querySelector("video").source;

        console.log({ raw, url, fallback });

        [...container.children].forEach((a) => {
          // console.log(a);
          //a.remove();
        });

        vid.src = url;
        //container.append(vid);
        //container.className = "video_container";

        //let fbLink = document.createElement("div").append(document.createElement("a"));
        //document.querySelector(".video-page").prepend(fbLink);

        //document.querySelectorAll("[data-role='related-item']").forEach((a) => {
        //a.querySelector("a").style = "height: 8rem; padding: unset;";
        //});
      } else {
        // document.querySelector(".player-container__player").remove(); //.forEach((a) => a.remove());
        a = document.querySelector(".player-container").querySelector("a").href;
        vid.src = a;
        // document.querySelector(".player-container").append(vid);
      }
      //document.querySelector("h1").parentNode.append(document.createElement("a").href = a);
      // vid.load();

      break;
    case "porn-radar":
    case "best":
    case "tags":
    case "categories":
    case "search":
      let filter = params.filter((a) => a.includes("filter="))[0].split("=")[1];
      console.log({ filter });

      const elements = window.mobileCheck()
        ? document.querySelectorAll(".thumb-list-mobile-item")
        : document.querySelectorAll(".thumb-list__item.video-thumb");
      elements.forEach((a) => {
        try {
          if (a.className.indexOf("widget") == -1) {
            if (a.querySelector(".video-thumb-info__name").title.toLowerCase().includes(filter)) {
              console.log(a);
              a.style.display = "none";
            }

            let time = window.mobileCheck()
              ? a.querySelector("time").innerText.split(":")
              : a.querySelector("[data-role='video-duration']").innerText.split(":");
            let seconds = parseInt(time[0]) * 60 + parseInt(time[1]);
            let views = a.querySelector(".video-thumb-views").innerText.split(" ")[0];
            // console.log({ seconds, views });

            a.querySelector(".video-uploader-data").innerText = `${views} views | ${seconds} seconds`;
            if (!window.mobileCheck()) a.querySelector(".video-thumb-info").style = "height: unset !important;";
          }
        } catch (e) {
          console.log(e);
        }
      });
      break;
    default:
      break;
  }
})();
