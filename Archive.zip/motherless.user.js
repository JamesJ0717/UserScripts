// ==UserScript==
// @name            motherless
// @version         2.0.10
// @description     This is your new file, start writing code
// @match           https://motherless.com/*
// @run-at          document-end
// ==/UserScript==

(function () {
  const page = location.pathname.split("/").filter((a) => a.length > 0)[0];
  console.log({ page });
  if (page.length == 7 || page.length == 8 || page == "g") {
    console.log("motherless.js");
    // console.log(__fileurl);

    addStyle(`
      .me-wide {
        max-width: 100vw !important;
        min-width: unset !important;
      }
    `);

    mobileCheck()
      ? document.querySelector(".container")
      : document.querySelector(".root-container").classList.add("me-wide");

    let vid = (
      mobileCheck() ? document.querySelector(".video-wrapper") : document.querySelector(".mediaspace-video-wrapper")
    ).querySelector("video");
    vid.parentElement.removeAttribute("class");
    //[...vid.children].forEach((a) => a.remove());
    // vid.style.width = "85vw";
    vid.style = `${mobileCheck() ? "width: 100%; height: auto;" : "height: 90vh; width: auto;"}; position: relative ;`;
    vid.src = __fileurl;
    vid.toggleAttribute("controls", true);
    vid.toggleAttribute("playsinline", true);
    vid.removeAttribute("class");

    document.querySelector("#content").style.margin = "unset";
    document.querySelector(".view-left").style.width = "100%";

    let fileLink = document.createElement("a");
    fileLink.href = __fileurl;
    fileLink.textContent = "Download mp4";
    fileLink.target = "_blank"; //("download", true);
    let headd = document.createElement("h1");
    headd.style.textDecoration = "underline";
    headd.style.color = "blue";
    headd.append(fileLink);

    let place = window.mobileCheck()
      ? document.querySelector(".ml-media-meta-title")
      : document.querySelector(".media-meta-title");

    place.appendChild(headd);
  } else if (/^https\:\/\/motherless\.com\/gv\/.*/gi.test(window.location.href)) {
    let a = document.querySelectorAll("a.title");
    a.forEach((a) => (a.textContent = a.textContent.split(" - ")[1]));
  }
})();
