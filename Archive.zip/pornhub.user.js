// ==UserScript==
// @name        pornhub
// @version     1.0.0
// @description This is your new file, start writing code
// @match       https://www.pornhub.com/*
// @run-at      document-idle
// ==/UserScript==

(function () {
  const url = window.location.href;
  switch (true) {
    case /view\_video\.php/.test(url):
      if (window.mobileCheck()) {
        // mobile stuff

        //rate-wrapper >
      } else {
        // not mobile
        document.querySelector("aside").remove();
        // document.querySelector("#tvWrapper > nav > div.js_active.js_zones.floatLeft.menuWrapper").remove();

        document.querySelectorAll(".control").forEach((a) => a.remove());
        document.querySelectorAll(".loading").forEach((a) => a.remove());
        document.querySelector("#hd-rightColVideoPage").remove();

        // <video controls="" preload="auto" style="width: 85vw; height: 100%;" accel-video="true" soda-loaded="true"><source src="" type="video/mp4"></video>
        let vid = document.getElementById("player").querySelector("video");
        console.log(vid);
        vid.controls = true;
        vid.preload = "auto";
        vid.setAttribute("disablePictureInPicture", false);
        vid.setAttribute("autoplay", false);
        vid.style = "width: auto !important; height: 85vh !important;";
        vid.removeAttribute("controlslist");
        vid.removeAttribute("class");
        vid.removeAttribute("autobuffer");
        document.querySelector("#player").remove();
        document.querySelector(".video-wrapper").prepend(vid);
        document.querySelector(".video-wrapper").style = "display: flex; flex-direction: column;";
        document.querySelector("#vpContentContainer").style = "grid-template-columns: none;";
      }
      break;
    default:
      break;
  }
})();
