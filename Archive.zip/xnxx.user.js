// ==UserScript==
// @name            xnxx
// @version         1.0.0
// @description     Stuff
// @match           *://www.xnxx.com/*
// @noframes
// ==/UserScript==

(function () {
  console.log(window.mobileCheck());
  const search = location.pathname.split("/").pop();
  if (location.pathname.includes("search")) {
    console.log(search);
    if (location.pathname.includes("hd-only") || location.pathname.includes("fullhd")) {
      // do nothing
    } else {
      location.pathname = location.pathname.replace(search, "fullhd/".concat(search));
    }
  }
})();
