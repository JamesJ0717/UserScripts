// ==UserScript==
// @name            xhamster-pre
// @version         1.0.0
// @license         MIT
// @author          James Johnson <james@jamesjohnson.io>
// @description     xhamster-pre
// @match           *://xhamster.com/*
// @match           *://xhamster2.com/*
// @run-at          document-end
// @noframes
// ==/UserScript==

(function () {
  addStyle(`
    main {
      padding: 1rem;
    }
    .thumb-list {
      height: unset !important;
      width: unset !important;
      min-height: unset !important;
      margin: auto !important;
    }
    .width-wrap { 
      max-width: unset !important;
    }
    .main-wrap {
      max-width: unset !important;
    }
    .hideo {
        display: none;
    }
    .player-container {
      margin: 10px auto !important; 
      overflow: unset !important;
    }
    .video_container {
      margin: auto; 
      width: 90vw;
    }
    .my-vid {
      width: 90vw;
      max-height: 90vh;
      margin: auto;
      backround: unset;
    }
  `);
})();
