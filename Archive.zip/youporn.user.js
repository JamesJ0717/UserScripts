// ==UserScript==
// @name        youporn
// @description This is your new file, start writing code
// @match       https://www.youporn.com/watch/*
// ==/UserScript==

let vid = document.querySelector("video");
vid.load();