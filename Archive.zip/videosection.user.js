// ==UserScript==
// @name        videosection
// @description This is your new file, start writing code
// @include       *://videosection.com/*video/*

// ==/UserScript==

(function(){
  const source = document.querySelector("video > source").src;
  console.log(source)
  let d = document.querySelector(".player-content");
  
  let link = document.createElement("a");
  link.href = source;
  link.innerText = "Watch here";
  document.querySelector(".player-detail__title").prepend(link);
})()