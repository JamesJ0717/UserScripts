// ==UserScript==
// @name            Code Formatter
// @version         1.0.0
// @description     Format and display code in a much better way
// @match           *://*/*.js
// @license         MIT
// ==/UserScript==
